function [c,p] = bsprice(S, k, r, T, sigma)

%Call and put prices of black-Scholes Equation
%%Inputs
%S0 = Current Stock price 
%k = strike price
%sigma = Volatility
%T: Time to maturity in years.
%r: risk free rate

%Author: Sivakumar Batthala
%MBA candidate
%Chicago Graduate School of Business
%University of chicago
%Date:02/23/2005
%Please email sbatthal@gsb.uchicago.edu for any clarifications or errors.
%For additional derivatives pricing models and guides, please visit
%http://www.global-derivatives.com

d1 = (log(S/k) + (r+(0.5*(sigma^2)))*T)/(sigma*sqrt(T));
d2 = d1 - (sigma*sqrt(T));
c = S*normcdfM(d1) - (k*exp(-r*T)*normcdfM(d2));
p = k*exp(-r*T)*normcdfM(-d2) - (S*normcdfM(-d1));