function C = rogewhaley(S0,k,r,T,sigma,D1,t1)

%Roll, Geske, Whaley approximation of an American Call Price
%Inputs
%S0 = Current Stock price (or) S0 reduced by present value of dividends
%except final dividend.
%D1 = final dividend amount
%k = strike price
%sigma = Volatility
%t1: final dividend date
%T: Time to maturity in years.
%r: risk free rate

% Please refer to the documentation in page 265 of HULL's Book
% When several dividends are anticipated, early exercise is optimal only
%on the final dividend. The RGW formula can be used with S0 reduced by
% the present value of all dividends except the final one. The variable D1
% should be set equal to the final dividend and t1 should be set equal to
% the final ex-dividend date.

%Author: Sivakumar Batthala
%MBA candidate
%Chicago Graduate School of Business
%University of chicago
%Date:02/23/2005
%Please email sbatthal@gsb.uchicago.edu for any clarifications or errors.
%For additional derivatives pricing models and guides, please visit
%http://www.global-derivatives.com

%Remove the following comment to run an example
%S0=39.5074;r=0.09;k=40;sigma=0.30;t1=5/12;T=6/12;D1=0.50; 

a1 = (log((S0 - (D1 * exp(-r*t1)))/k) + (r + (sigma.^2/2))*T)/(sigma*sqrt(T));

a2 = a1 - (sigma*sqrt(T));

% bsprice(S1)-S1 - D1 + k = 0 solve for S1;
% Time to maturity here is T -t1. When early exercise is never optimal, S_Star = inf; In this case,
% b1=b2=-INF. In other situation, option should be exercised at time t1
% when S(t1) > S_star + D1

% bisectional method of finding S_Star

S_star = bisect(S0,k,r,T,sigma,D1,t1);
   
b1 = (log((S0 - (D1 * exp(-r*t1)))/S_star) + (r + (sigma.^2/2))*t1)/(sigma*sqrt(t1));


b2 = b1 - (sigma * sqrt(t1));

C1 = (S0 - (D1 * exp(-r*t1))) * normcdfM(b1);
C2 = (S0 - (D1 * exp(-r*t1)))* bivnormcdf(a1,-b1,-sqrt(t1/T));
C3 = - k * exp(-r*T) * bivnormcdf(a2,-b2,-sqrt(t1/T));
C4 = - (k - D1)* exp(-r*t1)* normcdfM(b2);

%Final call price

C = C1+C2+C3+C4;
      