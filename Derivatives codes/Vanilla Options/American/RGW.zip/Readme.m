%Author: Sivakumar Batthala
%MBA candidate
%Chicago Graduate School of Business
%University of chicago
%Date:02/23/2005
%Please email sbatthal@gsb.uchicago.edu for any clarifications or errors.
READ ME:
Functions needed to run the main rogewhaley.m file
current dir : bisect
current dir : normcdfM
current dir : bivnormcdf