%d3f.m

% Andreas Andrikopoulos, 04/09/2006

% The derivative of the option price with respect to the boundary should be zero (boundary optimality)

function boundaryoptimality=d3f(S0,zeta, STRIKE, r, T, sigma)
% INPUTS
% S0 stock price
% STRIKE exercise price
% r interest rate
% T option life
% sigma volatility of annual stock returns

d1=(log(S0/STRIKE)+(r+0.5*sigma^2)*T)/(sigma*sqrt(T));
d2=d1-(sigma*sqrt(T));
p=STRIKE*exp(-r*T)*normcdf(-d2)-S0*normcdf(-d1);
K=1-exp(-zeta*T);
M=2*r/(sigma^2);
psi=zeta/r;
q1=0.5*(-(M-1)-sqrt((M-1)^2+4*M/K*(K+psi-psi*K)));
a11=(STRIKE-S0-blseuput(S0, STRIKE, r, T, sigma))/(K*S0^q1);
boundaryoptimality=((normcdf(-d1)-1)*S0^(-q1)-q1*(STRIKE-S0-p)*S0^(-q1-1));% The derivative of the option price with respect to the boundary