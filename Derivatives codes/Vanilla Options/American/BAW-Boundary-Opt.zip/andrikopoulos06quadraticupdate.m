%andrikopoulos06quadraticupdate.m

%Andreas Andrikopoulos, 04/09/2006
%http://www.global-derivatives.com

%adds an additional boundary condition to the Barone-Adesi and Whaley
%(1987) algorithm, resulting in better performance in the case of longer times to expiration .

function putp=andrikopoulos06quadraticupdate(S0, STRIKE, r, T, sigma);
% INPUTS
% S0 stock price
% STRIKE exercise price
% r interest rate
% T option life
% sigma volatility of annual stock returns

%Setting the increments for (numerically) solving the system of two
%equations and two unknowns
dx=0.00001;
dy=0.00001;
%initial guesses for the exercise boundary (x0) and zeta (yo)
x0=STRIKE;
y0=0.1*r;

p=blseuput(S0,STRIKE,r,T,sigma);%pricing the european put option on a stock that pays no dividends

% solving the system of two equations and two unknowns with the newton's
% method (derivatives approximated with dentral differences) 
fvec=zeros(2,1);%vector of function values
jvec=zeros(2,2);%vector of function derivatives
deltax=zeros(2,1);%vector of changes in variables
err=1;%initial error value

while err>0.00001
    jvec(1,1)=(d3f(x0+dx,y0,STRIKE, r, T, sigma)-d3f(x0-dx,y0,STRIKE, r, T, sigma))/(2*dx);
    jvec(1,2)=(d3f(x0,y0+dy,STRIKE, r, T, sigma)-d3f(x0,y0-dy,STRIKE, r, T, sigma))/(2*dy);
    jvec(2,1)=(d4f(x0+dx,y0,STRIKE, r, T, sigma)-d4f(x0-dx,y0,STRIKE, r, T, sigma))/(2*dx);
    jvec(2,2)=(d4f(x0,y0+dy,STRIKE, r, T, sigma)-d4f(x0,y0-dy,STRIKE, r, T, sigma))/(2*dy);
    fvec(1,1)=d3f(x0,y0,STRIKE, r, T, sigma);
    fvec(2,1)=d4f(x0,y0,STRIKE, r, T, sigma);
    fvec=-fvec;
    deltax=jvec\fvec;
    x0=deltax(1)+x0;
    y0=deltax(2)+y0;
    err=norm(deltax,2);
end
sstar=x0
zeta=y0
M=2*r/(sigma^2);
K=1-exp(-zeta*T);
psi=zeta/r;
q1=0.5*(-(M-1)-sqrt((M-1)^2+4*M/K*(K+psi-psi*K)));
d11=(log(sstar/STRIKE)+(r+sigma^2/2)*T)/(sigma*sqrt(T));
a1=(normcdf(-d11)-1)/(K*q1*sstar^(q1-1));
a11=(STRIKE-sstar-blseuput(sstar, STRIKE, r, T, sigma))/(K*sstar^q1);

if sstar<S0
   putp=p+K*a1*S0^q1;
else
    putp=STRIKE-S0;
end