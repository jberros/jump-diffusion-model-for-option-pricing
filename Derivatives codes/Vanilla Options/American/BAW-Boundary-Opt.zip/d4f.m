%d4fzeta. equating a1 and a11

%Andreas Andrikopoulos, 04/09/2006

%Combines the value-matching and the smooth-pasting conditions
function combinedterminal=d4f(S0,zeta, STRIKE, r, T, sigma)
%INPUTS
% S0 stock price
% STRIKE exercise price
% r interest rate
% T option life
% sigma volatility of annual stock returns
d1=(log(S0/STRIKE)+(r+0.5*sigma^2)*T)/(sigma*sqrt(T));
d2=d1-(sigma*sqrt(T));
p=STRIKE*exp(-r*T)*normcdf(-d2)-S0*normcdf(-d1);
K=1-exp(-zeta*T);
M=2*r/(sigma^2);
psi=zeta/r;
q1=0.5*(-(M-1)-sqrt((M-1)^2+4*M/K*(K+psi-psi*K)));
a1=(normcdf(-d1)-1)/(K*q1*S0^(q1-1)); %smooth-pasting
a11=(STRIKE-S0-blseuput(S0, STRIKE, r, T, sigma))/(K*S0^q1);%value-matching
combinedterminal=a1-a11;
