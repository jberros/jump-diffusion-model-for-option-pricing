%blseuput.m

%Andreas Andrikopoulos, 04/09/2006.

%Calculating the Black-Scholes price for a european put on a non-dividend
%paying asset
function price=blseuput(S0, STRIKE, r, T, sigma)
%INPUTS
% S0 stock price
% STRIKE exercise price
% r interest rate
% T option life
% sigma volatility of annual stock returns

d1=(log(S0/STRIKE)+(r+sigma^2/2)*T)/(sigma*sqrt(T));
d2=d1-(sigma*sqrt(T));
normcdf(-d2);
price=STRIKE*exp(-r*T)*normcdf(-d2)-S0*normcdf(-d1);